package aia.persistence.monadlearn

import cats.free._
import Operations.{ExprExtnd, _}
import akka.actor.Actor
import cats.data.State
import cats.~>

import scala.language.higherKinds

object FreeCoProductExample extends App {
  type K = List[Any]
  type OPST[A,T] = State[A, T]
  type OPTSTA[T] = OPST[K,_]

    def expr1(implicit arith : Arith[ExprExtnd],value : Value[ExprExtnd], valuea:ValueAND[ExprExtnd]): Free[ExprExtnd, Int] = {
      import arith._, value._, valuea._
      for {
        n <- intVal(2)
        f <- intVal(6)
        q <- intValan(2)
        m <- add(n, f)
        k <- add (f,m)
        v <- sub(k,n)
      } yield (v)
    }


    //val runTest = expr1.foldMap(testExtendedInterpreter).run(List.empty[String]).value
    implicit val interpreterimp = testExtendedInterpreter
    val runTest = foldAndRead(List.empty[String],()=>expr1)
    println(runTest._1)

    //val runProd = expr1.foldMap(interpreter).run(List.empty[String]).value
    //println(runProd)

  def foldAndRead(state:List[Any],programLogic :() =>Free[ExprExtnd, Int])(implicit interpreter: (ExprExtnd ~> State[List[Any], ?]))=
  {
    val kk = programLogic().foldMap(interpreter)
    val pp = kk.run(state).value
    pp
  }
}
