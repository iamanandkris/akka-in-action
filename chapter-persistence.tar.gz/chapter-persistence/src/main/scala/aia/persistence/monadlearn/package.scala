package aia.persistence

/**
  * Created by anand on 02/11/16.
  */
package object monadlearn {

}
